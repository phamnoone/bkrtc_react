var video_constraints = {
  mandatory: {
   	minWidth: 320,
	  maxWidth: 1280,
	  minHeight: 180,
	  maxHeight: 720,
	  minFrameRate: 30
  },
  optional:[]
};

var options = {
	video: video_constraints,
	audio: true
};

var peer = null;
var service = null;

$("#register").on("click", function() {
	var peer_name = $("#name").val();
	if(peer_name === "" || peer_name === null || peer_name === undefined) {
		alert("You must insert your user name");
		return;
	}
	peer = bkrtc.init("123");
	service = peer.stream_media(peer_name);
	handle_message(service);
});

$("#call").on("click", function() {
	var peer_name = $("#peer").val();
	if(service === null || peer === null || peer_name === "" || peer_name === null || peer_name === undefined) {
		alert("You must register and insert peer name");
		return;
	}
	// Get media user at local
	service.get_user_media(options, function(stream) {
		var local_stream = document.getElementById("local_stream");
		local_stream.src = window.URL.createObjectURL(stream);
    local_stream.play();
    service.call_user(peer_name, function(error) {
    	if(error) {
    		console.log(error);
    		add_log(error);
    		return;
    	}
    });
	},
	function(error) {
		console.log(error);
		add_log(error);
	});
});

$("#stop").on("click", function() {
	if(service === null || peer === null) {
		alert("You must register and insert peer name");
		return;
	}
	service.end_call();
});

function handle_message(service) {
	
	service.event.on("LOGGING", function(data) {
		console.log(data);
		add_log(data);
	});

	service.event.on("remote_stream", function(stream, peer_id) {
		add_stream_video(stream);
	});

	service.event.on("end_remote_stream", function(peer_id) {
		var video = document.getElementById("remote_stream");
		video.src = "";
	});

	service.event.on("MAKE_CALL", function(data) {
		service.get_user_media(options, function(stream) {
			var local_stream = document.getElementById("local_stream");
			local_stream.src = window.URL.createObjectURL(stream);
	    local_stream.play();
	    service.accept_call(data);
		},
		function(error) {
			console.log(error);
			add_log(error);
		});
	});
}

function add_log(data) {
	var ul = document.getElementById("console");
	var li = document.createElement("li");
	li.id = "message_log";
	li.innerHTML = data;
	ul.appendChild(li);
}

function add_stream_video(stream) {
	var video = document.getElementById("remote_stream");
	video.src = URL.createObjectURL(stream);
  video.autoplay = true;
}
