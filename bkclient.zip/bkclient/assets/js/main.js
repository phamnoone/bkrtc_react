var video_constraints = {
  mandatory: {
   	minWidth: 320,
	  maxWidth: 1280,
	  minHeight: 180,
	  maxHeight: 720,
	  minFrameRate: 30
  },
  optional:[]
};

var options = {
	video: video_constraints,
	audio: true
};

var peer = null;
var service = null;

$("#register").on("click", function() {
	var peer_name = $("#name").val();
	if(peer_name === "" || peer_name === null || peer_name === undefined) {
		alert("You must insert your user name");
		return;
	}
	peer = bkrtc.init("123");
	service = peer.stream_media(peer_name);
	handle_message(service);
});

$("#call").on("click", function() {
	var room_name = $("#room").val();
	if(service === null || peer === null || room_name === "" || room_name === null || room_name === undefined) {
		alert("You must register and insert room name");
		return;
	}
	// Get media user at local
	service.get_user_media(options, function(stream) {
		var local_stream = document.getElementById("local_stream");
		local_stream.src = window.URL.createObjectURL(stream);
    local_stream.play();
    service.call_room(room_name, function(error) {
    	if(error) {
    		console.log(error);
    		add_log(error);
    		return;
    	}
    });
	},
	function(error) {
		console.log(error);
		add_log(error);
	});
});

$("#stop").on("click", function() {
	var room_name = $("#room").val();
	if(service === null || peer === null || room_name === "" || room_name === null || room_name === undefined) {
		alert("You must register and insert room name");
		return;
	}
	service.end_call();
});

function handle_message(service) {
	
	service.event.on("LOGGING", function(data) {
		console.log(data);
		add_log(data);
	});

	service.event.on("remote_stream", function(stream, peer_id) {
		add_video(peer_id);
		add_stream_video(stream, peer_id);
	});

	service.event.on("end_remote_stream", function(peer_id) {
		var video = document.getElementById(peer_id);
		video.src = "";
		setTimeout(function() {
			remove_video(peer_id);
		}, 1000);
	});
}

function add_log(data) {
	var ul = document.getElementById("console");
	var li = document.createElement("li");
	li.id = "message_log";
	li.innerHTML = data;
	ul.appendChild(li);
}

function add_video(peer_id) {
	var ul = document.getElementById("remote_video");
	var li = document.createElement("li");
	var video = document.createElement("video");

	li.id = "remote_" + peer_id;
	video.id = peer_id;
	video.className = "remote_stream";
	video.poster = "webrtc.png";

	li.appendChild(video);
	ul.appendChild(li);
}

function add_stream_video(stream, peer_id) {
	var video = document.getElementById(peer_id);
	video.src = URL.createObjectURL(stream);
  video.autoplay = true;
}

function remove_video(peer_id) {
	var ul = document.getElementById("remote_video");
	var li = document.getElementById("remote_" + peer_id);
	ul.removeChild(li);
}