var option = {
  video: true,
  audio: true
};

// connect to server
rtcservice = bkrtc.create(username, key);
rtcservice.connect();


// create stream
rtcservice.createStream(option, function(stream) {
  document.getElementById('local').src = window.URL.createObjectURL(stream);
  document.getElementById('local').play();
});

// call to room
rtcservice.callRoom(room);
// call to peer
rtcservice.call(username);

// event add remote stream 
rtcservice.events.on('add_remote_stream', function(stream, socketId) {
  p2p.attachStream(stream, domId);
});

// event disconnect
rtcservice.events.on('disconnect_stream', function(data) {
  
});
