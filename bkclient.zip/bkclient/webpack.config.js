var webpack = require('webpack');

module.exports = {
  entry: "./index.js",
  output: {
    // path: "./build",
    // publicPath: "/build/",
    path: "/home/nguyenhoanganh/videochat/demo_bkrtc/lib",
    publicPath: "/home/nguyenhoanganh/videochat/demo_bkrtc/lib/",
    filename: "bkrtc.js"
  },
  module: {
    loaders: [
    { test: /\.js$/, loader: 'babel', exclude: /node_modules/ },
    
    ]
  },
  babel: {
    presets: ['es2015'],
    plugins: ['transform-runtime']
  },
  // co the co hoac khong
  debug: true,
  plugins: [
    // ...
    new webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: '"production"'
      }
    }),
    new webpack.optimize.UglifyJsPlugin({
      compress: {
        warnings: false
      }
    })
  ]
};

