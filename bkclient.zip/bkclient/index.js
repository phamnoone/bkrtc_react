
(function(window) {
	var BKPeer = require("./lib/bkpeer");
	window.bkrtc = {
		peer: {},
		create: function() {
			var bk_peer = new BKPeer();
			return bk_peer;
		},
		init: function(bk_peer, public_key, socket_client) {
			if(typeof bk_peer === "object" && typeof socket_client === "object") {
				this.peer = bk_peer.init(public_key, socket_client);
				return this.peer;
			}
			return null;
		},
		stream_media: function(user) {
			return this.peer.stream_media(user);
		},
		transfer_data: function(user) {
			return this.peer.transfer_data(user);
		}
	};
})(window);
