var fs = require('fs');
var express = require('express');
var app = express();
var server = require('http').createServer(app);
// var server = require('https').createServer({
//                                               key : fs.readFileSync("server.key"),
//                                               cert: fs.readFileSync("server.crt"),
//                                            }, app);

server.listen(8888);

app.use(express.static(__dirname + '/node_modules'));
app.use(express.static(__dirname + '/build'));
app.use(express.static(__dirname + '/assets'));
//app.use(express.static(__dirname + '/build'));

app.get('/multi_peer', function(req, res) {
  res.sendfile(__dirname + '/index1.html');
});

app.get('/single_peer', function(req, res) {
	res.sendfile(__dirname + '/index2.html');
});

// app.get('/index1', function(req, res) {
//   res.sendfile(__dirname + '/index1.html');
// });
