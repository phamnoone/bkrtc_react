# Hướng dẫn cách chạy ứng dụng: #
* Cài đặt nodejs:
    * Window: Vào trang chủ https://nodejs.org tải về bản mới nhất.
    * Linux: 
        * sudo apt-get update
        * sudo apt-get install nodejs 
        * cài đặt npm để quản lý các gói thư viện của nodejs: sudo apt-get install npm
        * Kiểm tra version của nodejs và npm. 
        * Update nodejs version mới nhất: curl -sL https://deb.nodesource.com/setup_0.12 | sudo bash - . Sau đó chạy lệnh: sudo apt-get install -y nodejs.
        * Update npm: npm update -g.
* Chạy ứng dụng:
    * Mở cửa sổ terminal(linux) hoặc cmd(window) cd vào folder ứng dụng.
        * Chạy lệnh npm install
        * Chạy node server.js 
        * Run: https://localhost và thêm ngoại lệ browser cho host này.
        * Run: https://localhost:8888/#ten_key và thêm ngoại lệ browser cho host này (phiên bản đang test nên phải gán key vào link)